/*
 * init_ADC.c
 *
 * Created: 07.03.2018 16:00:10
 *  Author: Moritz Klimt
 */ 
