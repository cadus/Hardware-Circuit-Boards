/*
 * TC2_8b_2ms.h
 *
 * Created: 07.03.2018 17:16:00
 *  Author: Moritz Klimt
 */ 


#ifndef TC2_8B_2MS_H_
#define TC2_8B_2MS_H_

void init_TC2_8b_2ms();

#endif /* TC2_8B_2MS_H_ */