/*
 * UART.h
 *
 * Created: 14.03.2018 12:21:33
 *  Author: Moritz Klimt
 */ 


#ifndef UART_H_
#define UART_H_

void init_UART_115200_8N1();
void SendData(int16_t data);



#endif /* UART_H_ */