/*
 * TC1_PWM_31kHz.h
 *
 * Created: 14.03.2018 08:50:40
 *  Author: Moritz Klimt
 */ 


#ifndef TC1_PWM_31KHZ_H_
#define TC1_PWM_31KHZ_H_


void init_TC1_PWM_4kHz();


#endif /* TC1_PWM_31KHZ_H_ */