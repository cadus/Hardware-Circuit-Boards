/*
 * init_ADC.h
 *
 * Created: 07.03.2018 16:00:38
 *  Author: Moritz Klimt
 */ 


#ifndef INIT_ADC_H_
#define INIT_ADC_H_

void init_ADC();



#endif /* INIT_ADC_H_ */